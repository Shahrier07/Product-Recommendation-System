-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 14, 2021 at 06:53 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `product_recommendation`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `pro_id` int(20) NOT NULL,
  `cat` varchar(20) NOT NULL,
  `price` int(20) NOT NULL,
  `pro_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `pro_id`, `cat`, `price`, `pro_name`) VALUES
(1, 2, 302, 'meat', 500, 'Beef'),
(2, 2, 301, 'meat', 201, 'Chicken'),
(3, 2, 201, 'food', 50, 'Bread'),
(4, 2, 201, 'food', 50, 'Bread'),
(5, 2, 505, 'mobile', 15000, 'Oppo'),
(6, 2, 505, 'mobile', 15000, 'Oppo');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(100) NOT NULL,
  `pro_id` int(100) NOT NULL,
  `pro_name` varchar(20) NOT NULL,
  `cat` varchar(20) NOT NULL,
  `price` int(100) NOT NULL,
  `sell` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `pro_id`, `pro_name`, `cat`, `price`, `sell`) VALUES
(1, 101, 'Mango', 'fruits', 100, 0),
(2, 201, 'Bread', 'food', 50, 0),
(3, 301, 'Chicken', 'meat', 201, 0),
(4, 501, 'Nokia', 'mobile', 13000, 0),
(5, 502, 'Samsung', 'mobile', 15000, 0),
(6, 503, 'Apple', 'mobile', 20000, 0),
(7, 505, 'Oppo', 'mobile', 15000, 0),
(8, 302, 'Beef', 'meat', 500, 0),
(9, 102, 'Lemon', 'fruits', 20, 0),
(10, 203, 'Butter', 'food', 50, 0),
(11, 901, 'Pen', 'study materials', 10, 0),
(12, 902, 'Paper', 'study materials', 30, 0),
(13, 701, 'Cream', 'body care', 100, 0),
(14, 702, 'Scent', 'body care', 250, 0),
(15, 703, 'Face Wash', 'body care', 120, 0),
(16, 704, 'Olive Oil', 'body care', 200, 0),
(17, 903, 'Book1', 'study materials', 100, 0),
(18, 904, 'Book2', 'study materials', 100, 0),
(19, 104, 'Orange', 'fruits', 150, 0),
(20, 105, 'Berry ', 'fruits', 50, 0),
(21, 106, 'Guava ', 'fruits', 30, 0),
(22, 305, 'lamb ', 'meat', 500, 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `pro_id` int(100) NOT NULL,
  `pro_name` varchar(20) NOT NULL,
  `cat` varchar(20) NOT NULL,
  `price` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`id`, `user_id`, `pro_id`, `pro_name`, `cat`, `price`) VALUES
(1, 3, 105, 'Berry ', 'fruits', 50),
(2, 3, 106, 'Guava ', 'fruits', 30),
(3, 3, 203, 'Butter', 'food', 50),
(4, 3, 101, 'Mango', 'fruits', 100),
(5, 3, 704, 'Olive Oil', 'body care', 200),
(6, 3, 302, 'Beef', 'meat', 500),
(7, 3, 305, 'lamb ', 'meat', 500),
(8, 3, 105, 'Berry ', 'fruits', 50),
(9, 3, 106, 'Guava ', 'fruits', 30),
(10, 3, 203, 'Butter', 'food', 50),
(11, 3, 101, 'Mango', 'fruits', 100),
(12, 3, 704, 'Olive Oil', 'body care', 200),
(13, 3, 302, 'Beef', 'meat', 500),
(14, 3, 305, 'lamb ', 'meat', 500),
(15, 3, 701, 'Cream', 'body care', 100),
(16, 3, 703, 'Face Wash', 'body care', 120),
(17, 3, 702, 'Scent', 'body care', 250),
(18, 3, 105, 'Berry ', 'fruits', 50),
(19, 3, 106, 'Guava ', 'fruits', 30),
(20, 3, 203, 'Butter', 'food', 50),
(21, 3, 101, 'Mango', 'fruits', 100),
(22, 3, 704, 'Olive Oil', 'body care', 200),
(23, 3, 302, 'Beef', 'meat', 500),
(24, 3, 305, 'lamb ', 'meat', 500),
(25, 3, 701, 'Cream', 'body care', 100),
(26, 3, 703, 'Face Wash', 'body care', 120),
(27, 3, 702, 'Scent', 'body care', 250),
(28, 3, 702, 'Scent', 'body care', 250),
(29, 3, 104, 'Orange', 'fruits', 150),
(30, 3, 503, 'Apple', 'mobile', 20000),
(31, 3, 503, 'Apple', 'mobile', 20000),
(32, 3, 503, 'Apple', 'mobile', 20000),
(33, 3, 503, 'Apple', 'mobile', 20000),
(34, 3, 503, 'Apple', 'mobile', 20000),
(35, 3, 503, 'Apple', 'mobile', 20000),
(36, 3, 503, 'Apple', 'mobile', 20000),
(37, 3, 503, 'Apple', 'mobile', 20000),
(38, 3, 503, 'Apple', 'mobile', 20000),
(39, 3, 302, 'Beef', 'meat', 500);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `username`, `password`) VALUES
(1, 'Md. Shahrier Sarder', 'shahriersarder@gmail', 'xxx', '81dc9bdb52d04dc20036'),
(2, 'Shoumik', 'shahriersarder@gmail', 'abc', '81dc9bdb52d04dc20036'),
(3, 'Sarder', 'shahriersarder@gmail', 'sss', '81dc9bdb52d04dc20036');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `purchase`
--
ALTER TABLE `purchase`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
