<?php session_start(); ?>
<?php
//including the database connection file
include("../connection.php");
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Main CSS -->
    <link rel="stylesheet" href="./css/style.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" >

    <title>Hello, world!</title>
  </head>
  <body>
      
     <!---Navbar starts-->
     <section class="header bg-light ">
     <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light ">
                <div class="container-fluid text-left">
                  <a class="navbar-brand" href="#"><img src="./images/logo.png" alt="logo" style="height: 30px; width: 110px;"></a>
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse justify-content-end " id="navbarNav">
                    <ul class="navbar-nav ">
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="../page_after_login/homepage_user.php">Home</a>
                        <p id="demo"></p>
                      </li>
                            
                      <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <?php echo $_SESSION['name']; ?>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href='../logout.php'>Logout</a>
                        </div>
                      </li>
                      
                    </ul>
                  </div>
                </div>
            </nav>
        </section>
        
        <!---Navbar ends-->  
        <div class="jumbotron">   
            <!--Registration -->
            
                <div class="container-fluid">
            <?php
            include("../connection.php");

            if(isset($_POST['submit'])) {
                $pro_id = $_POST['pro_id'];
                $pro_name = $_POST['pro_name'];
                $cat = $_POST['cat'];
                $price = $_POST['price'];
                $sell=  0;            
                // echo "$cat";

                if($pro_id == "" || $pro_name == "" ||  $cat  == "" || $price == "") {
                    echo "All fields should be filled. Either one or many fields are empty.";
                    echo "<br/>";
                    echo "<a href='./insert_product.php'>Go back</a>";
                } else {
                    mysqli_query($mysqli, "INSERT INTO product (pro_id, pro_name, cat, price, sell) VALUES('$pro_id', '$pro_name','$cat','$price', '$sell' )")
                        or die("Could not execute the insert query.");
                ?>

            <!-- After Successfull registration -->

            <div class="login-form" align="center">
                    <h2>Add successfully</h2>
                    <br/>
                    <h3><button class="btn btn-outline-primary"><a href='./show_product.php'>View Products</a></button></h3>
            </div>

            <!--  -->

        <?php
                }
            } else {
            ?>

            <div class="login-form">
            <form name="form1" method="post" action="">
                <h2 class="text-center">Insert Product</h2>     
                <p>Hints Category: ## fruits: id(100-199), ## food: id(200-299), ## meat: id(300-399), #Study Materials: id(900-999), ##body Care: id(700-799) </p>  
                <div class="form-group">
                    <input type="number" class="form-control" placeholder="Product Id" name="pro_id" required="required">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Product Name" name="pro_name" required="required">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Product Category" name="cat" required="required">
                </div>
                <div class="form-group">
                    <input type="number" class="form-control" placeholder="Product Price" name="price" required="required">
                </div>

                <div class="form-group">
                    <button type="submit" id="register" name="submit" class="btn btn-primary btn-block">Insert</button>
                </div>
     
            </form>
        </div>

        <?php
        }
        ?>

</div>
        <!--Registration Ends-->
        </div>









    </div>   <!--body part ends-->



    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>

  </body>
</html>



