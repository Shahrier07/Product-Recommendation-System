<?php session_start(); ?>
<?php
//including the database connection file
include("../connection.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Show Product</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <!-- Main CSS -->
  <link rel="stylesheet" href="./css/style.css">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
  
     <!---Navbar starts-->
     <section class="header bg-light ">
         <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light ">
                <div class="container-fluid text-left">
                  <a class="navbar-brand" href="#"><img src="../images/logo.png" alt="logo" style="height: 40px; width: 40px;"></a>
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse justify-content-end " id="navbarNav">
                    <ul class="navbar-nav ">
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="../index.php">Home</a>
                        <p id="demo"></p>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="./products/insert_product.php">Products</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="../registration.php">Registration</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="../login.php">Log In</a>
                      </li>
                      
                    </ul>
                  </div>
                </div>
            </nav>
        </section>
        
        <!---Navbar ends-->  

        <!---Main Body Starts--->
<!--Product Section-->
    
   
<div class="container-fluid ">
 
 <div class="products text-center col-lg-11">
     <?php
     $result = mysqli_query($mysqli, "SELECT * FROM product ORDER BY pro_id asc");//fetch from product
     while($res = mysqli_fetch_array($result)) {  
     ?>   
     <div class="card m-3 col-lg-2 col-md-3 float-left" >
         <form name="form1" method="post" action="">
             <img class="card-img-top" src="../images/fake_image.png" alt="Card image">
             <div class="card-body">
                 <h4 class="card-title"><?php echo $res['pro_name']; ?></h4>
                 <p class="card-text">Category:  <?php echo $res['cat']; ?>.</p>
                 <p class="card-text">Price:  <?php echo $res['price']; ?>.</p>
             </div>
             <button type="submit" id="register" name="submit" class="btn btn-primary btn-block" onclick="myFunction() ">Add To Cart</button> <!--add to the cart-->
         </form>      
     </div>

     <?php } ?>
  </div>


  <!--Cart-->
  <div class="cart">
         <h1>Cart</h1>
 </div>
</div>

</div>   <!--body part ends-->

 


 <!--Js -->
 <!--Main Js--->

 <script>
   function myFunction() {
     alert("To add Cart Login First");
   }
 </script>





  <!--Js link-->
 <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" ></script>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>