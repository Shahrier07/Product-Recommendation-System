<?php session_start(); ?>
<?php
//including the database connection file
include("../connection.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Show Product</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="./css/style.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  </head>
  <body>
    
    <!---Navbar starts-->
    <section class="header bg-light ">
      <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light ">
          <div class="container-fluid text-left">
            <a class="navbar-brand" href="#"><img src="../images/logo.png" alt="logo" style="height: 40px; width: 40px;"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end " id="navbarNav">
              <ul class="navbar-nav ">
                <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="homepage_user.php">Home</a>
                  <p id="demo"></p>
                </li>
                <li class="nav-item">
                  <a class="nav-link dropdown-toggle" href="../products/insert_product.php">Insert Products</a>
                  
                </li>
                
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php echo $_SESSION['name']; ?>
                  </a>
                  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href='../logout.php'>Logout</a>
                  </div>
                </li>
                
              </ul>
            </div>
          </div>
        </nav>
      </section>
      
      <!---Navbar ends-->
      <!---Main Body Starts--->
      <div class="container-fluid">

        <!---Show Recommended Product-->
        <section class="products text-center mt-5 col-lg-10 float-left ">
          <h4>Recommended for you</h4>
          
          <?php
          $user_id = $_SESSION['id'];

          /*
          $result = mysqli_query($mysqli, "SELECT *, count(cat) as amount FROM purchase where user_id= '$user_id' GROUP BY cat ORDER BY amount DESC 
          LIMIT 5 ");//fetch from product
          */

          ///From Purchase DB
          $result = mysqli_query($mysqli, "Select  * From product WHERE  cat 
          IN(SELECT cat from purchase WHERE purchase.user_id=$user_id  UNION ALL SELECT cat from cart WHERE  cart.user_id=$user_id
           ORDER BY cat desc) limit 6
          ");//fetch from product
          
          
          



          while($res = mysqli_fetch_array($result)) {
          ?>
          <div class="card col-lg-2 col-md-3 col-sm-4 float-left" >
            <form name="form1" method="post" action="">
              <img class="card-img-top" src="../images/fake_image.png" alt="Card image">
              <div class="card-body">
                <h4 class="card-title"><?php echo $res['pro_name']; ?></h4>
                <p class="card-text">Category:  <?php echo $res['cat']; ?>.</p>
                <p class="card-text">Price:  <?php echo $res['price']; ?>.</p>
              </div>
              <input type="hidden" name="hidden_id" value="<?php echo $res["pro_id"]; ?>" />
              <input type="hidden" name="hidden_name" value="<?php echo $res["pro_name"]; ?>" />
              <input type="hidden" name="hidden_cat" value="<?php echo $res["cat"]; ?>" />
              <input type="hidden" name="hidden_price" value="<?php echo $res["price"]; ?>" />
              <button type="submit" id="register" name="submit" class="btn btn-primary btn-block">Add To Cart</button> <!--add to the cart-->
            </form>
          </div>
          <?php } ?>
          
          <hr>
        </section>






      <!--Cart-->
      <section>
        <div class="cart text-center col-2 float-left">
          <h1>Cart</h1>
          <!--Adding to the cart--->
          <?php
          $res = mysqli_fetch_array($result); //fetch result

          $count =0;
          if(isset($_POST['submit'])) {
          
          $user_id = $_SESSION['id'];
         
          $pro_id = $_POST['hidden_id'];
          $pro_name = $_POST['hidden_name'];
          $cat = $_POST['hidden_cat'];
          $price = $_POST['hidden_price'];
          
          //echo "$user_id";
          
          
          mysqli_query($mysqli, "INSERT INTO cart (user_id, pro_id, cat, price, pro_name) VALUES('$user_id', ' $pro_id','$cat','$price', '$pro_name' )")
          or die("Could not execute the insert query.");
          ?>
          
          <!-- After Successfull addition -->
          
          <div class="login-form" align="center">
            <h4 class="text-success">Add successfully</h4>
            <a href="../cart/show_cart.php" target="_blank">show cart</a>
            <br/>
          </div>
          
          <!--  -->
          
          
          <?php
          } // ends here
          ?>  
        </div>
      </section>  


        <div class="clearfix"></div>
        <!--Products-->
        <section>
          <div class="products text-center mt-5 col-lg-10" data-spy="scroll">
            <h1>Products</h1>
            <?php
            $result = mysqli_query($mysqli, "SELECT * FROM product ORDER BY pro_id asc");//fetch from product
            while($res = mysqli_fetch_array($result)) {
            ?>
            <div class="card m-3 col-lg-2 col-md-3 col-sm-4 float-left" >
              <form name="form1" method="post" action="">
                <img class="card-img-top" src="../images/fake_image.png" alt="Card image">
                <div class="card-body">
                  <h4 class="card-title"><?php echo $res['pro_name']; ?></h4>
                  <p class="card-text">Category:  <?php echo $res['cat']; ?>.</p>
                  <p class="card-text">Price:  <?php echo $res['price']; ?>.</p>
                </div>
                <input type="hidden" name="hidden_id" value="<?php echo $res["pro_id"]; ?>" />
                <input type="hidden" name="hidden_name" value="<?php echo $res["pro_name"]; ?>" />
                <input type="hidden" name="hidden_cat" value="<?php echo $res["cat"]; ?>" />
                <input type="hidden" name="hidden_price" value="<?php echo $res["price"]; ?>" />
                <button type="submit" id="register" name="submit" class="btn btn-primary btn-block">Add To Cart</button> <!--add to the cart-->
              </form>
            </div>
            <?php } ?>
          </div>
        </section>
       
        
      </div>
    </body>
  </html>