<?php
//including the database connection file
include_once("./connection.php");
?>



<!doctype html>
<html lang="en">
  <head>
  <title>Hello, world!</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Main CSS -->
    <link rel="stylesheet" href="./css/style.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" >

    <!--my js-->
    <script src="./js/app.js"></script>
   
  </head>
  <body>
      
     <!---Navbar starts-->
     <section class="header bg-light ">
     <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light ">
                <div class="container-fluid text-left">
                  <a class="navbar-brand" href="#"><img src="./images/logo.png" alt="logo" style="height: 40px; width: 40px;"></a>
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse justify-content-end " id="navbarNav">
                    <ul class="navbar-nav ">
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="./index.php">Home</a>
                        <p id="demo"></p>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="./products/show_product.php">Products</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="registration.php">Registration</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="./login.php">Log In</a>
                      </li>
                      
                    </ul>
                  </div>
                </div>
            </nav>
        </section>
        
        <!---Navbar ends-->  




       <!--Registration -->
  
    <div class="registration col-6 float-left">
          
            <?php
            include("./connection.php");

            if(isset($_POST['submit'])) {
                $name = $_POST['name'];
                $email = $_POST['email'];
                $user = $_POST['username'];
                $pass = $_POST['password'];

                if($user == "" || $pass == "" || $name == "" || $email == "") {
                    echo "All fields should be filled. Either one or many fields are empty.";
                    echo "<br/>";
                    echo "<a href='register.php'>Go back</a>";
                } else {
                    mysqli_query($mysqli, "INSERT INTO users(name, email, username, password) VALUES('$name', '$email', '$user', md5('$pass'))")
                        or die("Could not execute the insert query.");
                ?>

            <!-- After Successfull registration -->

            <div class="login-form" align="center">
                    <h2>Registration successfully</h2>
                    <br/>
                    <h3><button class="btn btn-outline-primary"><a href='login.php'>Go to Login</a></button></h3>
            </div>

            <!--  -->

        <?php
                }
            } else {
            ?>

            <div class="login-form">
            <form name="form1" method="post" action="">
                <h2 class="text-center">Sign Up</h2>       
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Full Name" name="name" required="required">
                </div>

                <div class="form-group">
                    <input type="email" class="form-control" placeholder="Email" name="email" required="required">
                </div>

                <div class="form-group">
                    <input type="text" class="form-control" id="txt_username" placeholder="Username" name="username" required="required">
                    <div id="uname_response" ></div>
                </div>

                <div class="form-group">
                    <input type="password" class="form-control" placeholder="Password" name="password" required="required">
                </div>

                <div class="form-group">
                    <button type="submit" id="register" name="submit" class="btn btn-primary btn-block">Register</button>
                </div>

                <div class="clearfix">
                    <a href="login.php" class="float-right">Already have an account?</a>
                </div>        
            </form>
        </div>

        <?php
        }
        ?>
  </div>
  </div>

        <!--Registration Ends-->
  <!--body part ends-->



    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>

  </body>
</html>



