<?php session_start(); ?>
<?php
//including the database connection file
include("../connection.php");


?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>login page</title>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="js/jquery.js"></script> 
   
  <script src="media/js/jquery.dataTables.min.js"></script>
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
    
  

<style>
 
</style>
</head>

<body>
  <!---Navbar starts-->
  <section class="header bg-light ">
     <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light ">
                <div class="container-fluid text-left">
                  <a class="navbar-brand" href="#"><img src="../images/logo.png" alt"logo" style="height: 40px; width: 40px;"></a>
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse justify-content-end " id="navbarNav">
                    <ul class="navbar-nav ">
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="./index.php">Home</a>
                        <p id="demo"></p>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="./products/show_product.php">Products</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="./registration.php">Registration</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="./login.php">Log In</a>
                      </li>
                      
                    </ul>
                  </div>
                </div>
            </nav>
        </section>
        
        <!---Navbar ends-->  
  

     

      <div class="container-fluid">

      
          <!--Adding to the purchase--->
          <?php
                $user_id = $_SESSION['id'];
                $result = mysqli_query($mysqli, "SELECT * FROM cart WHERE user_id = $user_id");//fetch from product
                $res = mysqli_fetch_array($result); //fetch result 
                
                
                if(isset($_POST['submit'])) {
                    
                    $user_id = $_SESSION['id'];
                    $name = $_SESSION['name'];
                    
                    $pro_id = $_res['pro_id'];
                    $pro_name = $_res['pro_name'];
                    $cat = $_res['cat'];
                    $price = $_res['price'];
                           
                    //echo "$user_id";
    
                   
                        mysqli_query($mysqli, "INSERT INTO cart (user_id, pro_id, cat, price, pro_name) VALUES('$user_id', ' $pro_id','$cat','$price', '$pro_name' )")
                            or die("Could not execute the insert query.");
            ?>


                
                <!-- After Successfull addition -->
    
                <div class="login-form" align="center">
                        <h4 class="text-success">Add successfully</h4>
                        <a href="../cart/show_cart.php">show cart</a>
                        <br/>
                </div>
    
                <!--  -->
            
           
            <?php
                } // ends here   
        ?>









    <!---Login--> 
    
      </div>



</body>

</html>
