<?php session_start(); ?>

<?php
//including the database connection file
include("../connection.php");
$user_id = $_SESSION['id'];
$result = mysqli_query($mysqli, "SELECT * FROM cart WHERE user_id = $user_id");//fetch from product

?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Main CSS -->
    <link rel="stylesheet" href="./css/style.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>View Cart</title>
  </head>
  <body>
      
     <!---Navbar starts-->
     <section class="header bg-light ">
     <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light ">
                <div class="container-fluid text-left">
                  <a class="navbar-brand" href="#"><img src="../images/logo.png" alt="logo" style="height: 40px; width: 40px;"></a>
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse justify-content-end " id="navbarNav">
                    <ul class="navbar-nav ">
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                        <p id="demo"></p>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="./products/insert_product.php">Products</a>
                      </li>
                      <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <?php echo $_SESSION['name']; ?>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href='../logout.php'>Logout</a>
                            </div>
                      </li>
                      
                    </ul>
                  </div>
                </div>
            </nav>
        </section>
        
        <!---Navbar ends-->  

   

     <!--Cart-->
     <div class="cart text-center">
            <h1>Show Cart</h1>
            <!--Show Cart items--->
        <div class="container">
          <!---show Data in Table--->
        <table id="Cart_table" class="table table-striped table-bordered " style="width:50%"> 
         <thead>
           <tr>
             <th class="th-sm">Name
             </th>
             <th class="th-sm">Category
             </th>
             <th class="th-sm">Price
             </th>
            
           </tr>
         </thead>
         
         
         <form name="form1" method="post" action=""> 
          <?php  
            while($res = mysqli_fetch_array($result)) {   
              echo "<tr>";
              echo "<td>".$res['pro_name']."</td>";
              echo "<td>".$res['cat']."</td>";
              echo "<td>".$res['price']."</td>";
            }
          ?>  
          <div class="form-group">
                    <button type="submit" id="register" name="submit" class="btn btn-primary btn-block" style="width: 20%">Purchase</button>
          </div>
          </form>



            <!--Adding to the purchase db--->
          <?php
                $user_id = $_SESSION['id'];
                $result = mysqli_query($mysqli, "SELECT * FROM cart WHERE user_id = $user_id");//fetch from product
                //fetch result 
                
                
                if(isset($_POST['submit'])) {
                  while($res = mysqli_fetch_array($result)) { 
                    $user_id = $_SESSION['id'];
                    
                    $pro_id = $res['pro_id'];
                    $pro_name = $res['pro_name'];
                    $cat = $res['cat'];
                    $price = $res['price'];
                           
                    //echo "$user_id";
    
                   
                        mysqli_query($mysqli, "INSERT INTO purchase (user_id, pro_id, pro_name, cat, price) VALUES('$user_id', ' $pro_id', '$pro_name', '$cat','$price' )")
                            or die("Could not execute the insert query.");
                  }          

            ?>


                
                <!-- After Successfull addition -->
    
                <div class="login-form" align="center">
                        <h4 class="text-success">Purchase successfully</h4>
                        <a href="../page_after_login/homepage_user.php">Goto Homepage</a>
                        <br/>
                </div>
    
                <!--  -->
            
           
            <?php
                } // ends here   
        ?>
          






          
        </div>
    </div>
</div>

</div>   <!--body part ends-->

    


    <!--Js -->
    <!--Main Js--->

    <script>
      function myFunction() {
        alert("To add Cart Login First");
      }
    </script>





     <!--Js link-->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>

  </body>
</html>