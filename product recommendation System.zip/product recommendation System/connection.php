<?php

$databaseHost = 'localhost';
$databaseName = 'product_recommendation';
$databaseUsername = 'root';
$databasePassword = '';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
	
?>