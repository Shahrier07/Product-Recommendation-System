

//login alert 
      function myFunction() {
        alert("To add Cart Login First");
      }
